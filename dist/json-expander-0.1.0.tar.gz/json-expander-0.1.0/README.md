# json_expand
Generate Json Data of Desired objects with only one object as example.
