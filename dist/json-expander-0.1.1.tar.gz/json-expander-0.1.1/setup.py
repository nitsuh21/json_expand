from setuptools import setup, find_packages

setup(
    name='json-expander',
    version='0.1.1',
    packages=find_packages(),
    install_requires=[
        
    ],
    url='https://github.com/nitsuh21/json_expand.git'
)
